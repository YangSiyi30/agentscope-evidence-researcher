## 结论

**不能保证调用方不收到 `CancelledError`。** 官方文档称 `asyncio.shield(aw)` 是“保护可等待对象不被取消”：若 `aw` 是协程会自动调度为 Task；若包含该 `await` 的协程被取消，`something()` 所在 Task 不被取消，从其视角取消未发生，但**调用方仍处于被取消状态，该 `await` 表达式依然抛出 `CancelledError`** [SRC-86481391@page]。

区分：
- **被保护任务**：不受影响，取消未发生 [SRC-86481391@page]。
- **调用方**：仍会收到 `CancelledError`，shield 不豁免这一点 [SRC-86481391@page]。

因此 shield 保护被包装对象，而非吞掉调用方的取消。

## 证据与局限

来源为官方《Coroutines and tasks》“Shielding from cancellation”小节，页面标题 Python 3.14.7 文档 [SRC-86481391@snippet]；本次读取为有限片段，未核验整页 [SRC-86481391@page]。非官方旁证方向一致，仅作参考 [SRC-B32E5F29@snippet]。

片段省略了代码块及部分上下文，等价写法完整代码未核验 [SRC-86481391@page]；其他版本措辞、超时/嵌套取消/`uncancel()` 等场景均未核验，证据不足。